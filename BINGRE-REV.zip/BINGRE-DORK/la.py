#!/usr/bin/env python3
"""
la.py — Bing Domain Harvester: dork mode + IP mode (local-only)

TWO MODES:
  1. DORK — feed search queries, collect result domains (as before)
  2. IP   — feed an IP list, for each IP search Bing (ip:<address>) and
            collect every site hosted on that address (reverse via search)

All resources are LOCAL:
    top_181_domain_filter.txt  — exclusion list
    proxies.txt                — optional proxies

Settings in settings.ini: use_proxy / max_workers / request_timeout

Usage:
    py -3 la.py
    -> choose mode (1=dork, 2=ip)
    -> dork mode: enter dork list file
    -> ip mode:   enter IP list file (one IP per line)

Dependencies:
    py -3 -m pip install requests colorama
"""

import sys
import time
import platform
import re
import ipaddress
import threading
import configparser
from pathlib import Path
from typing import Set, Optional, List, Dict, Iterator
from concurrent.futures import ThreadPoolExecutor, as_completed
from itertools import cycle
from urllib.parse import quote, urlparse
import ctypes

import requests
from requests.exceptions import RequestException
import urllib3
from colorama import Fore, Style, init as colorama_init

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
colorama_init(autoreset=True)


# ============================================================================
# COLORS
# ============================================================================

class Colors:
    GREEN = "\033[1;32;40m"
    RED = "\033[1;31;40m"
    YELLOW = "\033[1;33;40m"
    CYAN = "\033[1;36;40m"
    RESET = "\033[0m"
    BOLD = Style.BRIGHT
    MAGENTA = Fore.MAGENTA
    RESET_ALL = Style.RESET_ALL


# ============================================================================
# CONFIG
# ============================================================================

class Config:
    OUTPUT_FILE = "Domains.txt"
    SETTINGS_FILE = "settings.ini"
    EXCLUSION_FILE = "top_181_domain_filter.txt"   # local only
    PROXY_FILE = "proxies.txt"                    # local only

    BING_HOST = "http://www.bing."
    BING_SEARCH_PATH = "/search?q="
    BING_EXTRA = "&count=50&first="

    REGIONS = ["com", "de", "fr", "it", "co.jp", "co.uk", "es", "ca",
               "com.au", "com.tr", "ch", "nl", "se", "pl", "vn"]

    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
        "(KHTML, like Gecko) Version/17.0 Safari/605.1.15",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) "
        "Gecko/20100101 Firefox/126.0",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36 Edg/125.0.0.0",
    ]

    BANNER = f"""{Colors.MAGENTA}{Style.BRIGHT}
    ____  __                ____
   / __ \\/ /_  _______     / __ \\____ ______________  _____
  / /_/ / / / / / ___/    / /_/ / __ `/ ___/ ___/ _ \\/ ___/
 / ____/ / /_/ (__  )    / ____/ /_/ / /  (__  )  __/ /
/_/   /_/\\__,_/____/    /_/    \\__,_/_/  /____/\\___/_/

       la.py — Bing Harvester | dork mode + IP (reverse) mode
       TELEGRAM CHANNEL: https://t.me/opsecClip
{Colors.RESET}"""


# ============================================================================
# SETTINGS — settings.ini
# ============================================================================

class Settings:
    def __init__(self):
        self.use_proxy = False
        self.max_workers = 20
        self.request_timeout = 15

    def load(self) -> "Settings":
        path = Path(Config.SETTINGS_FILE)
        if not path.exists():
            self._create_default()
        parser = configparser.ConfigParser()
        try:
            parser.read(Config.SETTINGS_FILE, encoding="utf-8")
            section = parser["SETTINGS"]
            self.use_proxy = section.get("use_proxy", "no").strip().lower() \
                in ("yes", "y", "true", "on", "1")
            self.max_workers = max(1, min(100,
                section.getint("max_workers", 20)))
            self.request_timeout = max(5, min(60,
                section.getint("request_timeout", 15)))
        except (configparser.Error, KeyError, ValueError) as e:
            print(f"{Colors.YELLOW}[!] settings.ini problem ({e}) — "
                  f"using defaults{Colors.RESET}")
        return self

    def _create_default(self):
        content = (
            "[SETTINGS]\n"
            "# yes = route Bing searches through proxies.txt\n"
            "# no  = search direct from your own IP\n"
            "use_proxy = no\n"
            "\n"
            "# parallel threads (1-100)\n"
            "max_workers = 20\n"
            "\n"
            "# seconds per Bing request (5-60)\n"
            "request_timeout = 15\n"
        )
        try:
            Path(Config.SETTINGS_FILE).write_text(content, encoding="utf-8")
            print(f"{Colors.GREEN}[+] Created {Config.SETTINGS_FILE} — "
                  f"edit it to change settings{Colors.RESET}")
        except OSError as e:
            print(f"{Colors.RED}[!] Could not write settings.ini: {e}"
                  f"{Colors.RESET}")


# ============================================================================
# PROXY MANAGER (local proxies.txt only)
# ============================================================================

class ProxyManager:
    def __init__(self):
        self.proxies: List[str] = []
        self._cycle: Optional[Iterator[str]] = None
        self._enabled = False
        self._lock = threading.Lock()

    def load(self):
        try:
            local = Path(Config.PROXY_FILE)
            if not local.exists():
                print(f"{Colors.YELLOW}[!] {Config.PROXY_FILE} not found — "
                      f"searching direct{Colors.RESET}")
                return
            text = local.read_text(encoding="utf-8", errors="ignore")
            self.proxies = [l.strip() for l in text.splitlines()
                           if l.strip().startswith("http")]
        except OSError as e:
            print(f"{Colors.RED}[!] Proxy file read error: {e}{Colors.RESET}")
            self.proxies = []
        if self.proxies:
            self._cycle = cycle(self.proxies)
            self._enabled = True
            print(f"{Colors.GREEN}[+] {len(self.proxies)} proxies loaded "
                  f"(local){Colors.RESET}")
        else:
            self._enabled = False
            print(f"{Colors.YELLOW}[!] proxies.txt is empty — "
                  f"searching direct{Colors.RESET}")

    def get_next(self) -> Optional[str]:
        with self._lock:
            if not self._enabled or not self._cycle:
                return None
            return next(self._cycle)

    def rotate(self) -> Optional[Dict[str, str]]:
        proxy = self.get_next()
        if not proxy:
            return None
        return {"http": proxy, "https": proxy}

    @property
    def enabled(self) -> bool:
        return self._enabled


# ============================================================================
# EXCLUSION FILTER (local file only)
# ============================================================================

class ExclusionFilter:
    def __init__(self):
        self.excluded: Set[str] = set()

    def load(self):
        local = Path(Config.EXCLUSION_FILE)
        if not local.exists():
            print(f"{Colors.YELLOW}[!] {Config.EXCLUSION_FILE} not found — "
                  f"running unfiltered{Colors.RESET}")
            self.excluded = set()
            return
        try:
            text = local.read_text(encoding="utf-8", errors="ignore")
        except OSError as e:
            print(f"{Colors.RED}[!] Exclusion file read error: {e}"
                  f"{Colors.RESET}")
            self.excluded = set()
            return
        self.excluded = {
            line.strip().lower()
            for line in text.splitlines() if line.strip()
        }
        print(f"{Colors.GREEN}[+] {len(self.excluded)} exclusions loaded "
              f"(local){Colors.RESET}")

    def is_excluded(self, domain: str) -> bool:
        domain = domain.lower()
        if domain in self.excluded:
            return True
        parts = domain.split(".")
        for i in range(len(parts)):
            candidate = ".".join(parts[i:])
            if candidate in self.excluded:
                return True
        return False


# ============================================================================
# BING SEARCH ENGINE — shared by both dork and IP modes
# ============================================================================

class BingSearchEngine:
    PATTERN = re.compile(r"<cite>(.*?)</cite>", re.DOTALL)
    TAG_RE = re.compile(r"<[^>]+>")

    def __init__(self, proxy_manager: ProxyManager,
                 exclusion_filter: "ExclusionFilter", settings: Settings):
        self.proxy_manager = proxy_manager
        self.exclusion_filter = exclusion_filter
        self.settings = settings
        self._region_cycle = cycle(Config.REGIONS)

    def _build_headers(self) -> Dict[str, str]:
        import random
        return {
            "User-Agent": random.choice(Config.USER_AGENTS),
            "Accept": ("text/html,application/xhtml+xml,application/xml;"
                       "q=0.9,image/webp,*/*;q=0.8"),
            "Accept-Language": "en-US,en;q=0.5",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        }

    def _make_request(self, session: requests.Session, url: str):
        attempts = 2 if self.proxy_manager.enabled else 1
        for attempt in range(attempts):
            proxies = (self.proxy_manager.rotate()
                       if self.proxy_manager.enabled else None)
            try:
                response = session.get(
                    url, headers=self._build_headers(),
                    timeout=self.settings.request_timeout,
                    proxies=proxies, verify=False)
                if self._check_captcha(response):
                    print(f"{Colors.YELLOW}[!] Captcha detected, "
                          f"skipping...{Colors.RESET}")
                    return None
                return response
            except RequestException as e:
                if not self.proxy_manager.enabled:
                    print(f"{Colors.RED}[!] Request failed: {e}"
                          f"{Colors.RESET}")
                    return None
                continue
        return None

    def _check_captcha(self, response) -> bool:
        return "captcha" in response.text.lower()

    def _extract_domain(self, cite_text: str) -> Optional[str]:
        text = cite_text.strip()
        text = text.split("›")[0].strip()
        if not text.startswith(("http://", "https://")):
            text = "http://" + text
        parsed = urlparse(text)
        domain = parsed.netloc or parsed.path.split("/")[0]
        if domain.startswith("www."):
            domain = domain[4:]
        if not domain or "." not in domain:
            return None
        if not re.fullmatch(r"[A-Za-z0-9.-]+", domain):
            return None
        if self.exclusion_filter.is_excluded(domain):
            return None
        return domain

    def _search_raw(self, query: str):
        """Run one encoded query on one regional Bing, return response."""
        session = requests.Session()
        encoded = quote(query)
        region = next(self._region_cycle)
        url = (f"{Config.BING_HOST}{region}{Config.BING_SEARCH_PATH}"
              f"{encoded}{Config.BING_EXTRA}0")
        response = self._make_request(session, url)
        return region, response

    def _parse_domains(self, response_text: str) -> Set[str]:
        found: Set[str] = set()
        for match in self.PATTERN.findall(response_text):
            cleaned = self.TAG_RE.sub("", match)
            cleaned = (cleaned.replace("<strong>", "")
                              .replace("</strong>", "")
                              .replace('<span dir="ltr">', ""))
            domain = self._extract_domain(cleaned)
            if domain:
                found.add(domain)
        return found

    # -- mode: dork ------------------------------------------------------

    def search_dork(self, dork: str) -> Set[str]:
        """Dork in, domains out."""
        region, response = self._search_raw(dork)
        if not response:
            return set()
        found = self._parse_domains(response.text)
        for domain in found:
            print(f"{Colors.CYAN}[Bing-{region} dork] - [+] {domain}"
                  f"{Colors.RESET}")
        return found

    # -- mode: IP --------------------------------------------------------

    def search_ip(self, ip: str) -> Set[str]:
        """IP in, hosted domains out.

        Two queries per IP: the 'ip:' operator (Bing's indexed site-to-IP
        mapping) and the bare IP string (catches sites that quote the address
        in content). Results merged.
        """
        found: Set[str] = set()
        queries = [f"ip:{ip}", ip]
        for query in queries:
            region, response = self._search_raw(query)
            if not response:
                continue
            found |= self._parse_domains(response.text)
        for domain in found:
            print(f"{Colors.CYAN}[Bing-{region} ip:{ip}] - [+] {domain}"
                  f"{Colors.RESET}")
        return found


# ============================================================================
# DOMAIN REPOSITORY
# ============================================================================

class DomainRepository:
    def __init__(self, filepath: str = Config.OUTPUT_FILE):
        self.filepath = Path(filepath)
        self._domains: Set[str] = set()
        self._lock = threading.Lock()

    def reset(self):
        self._domains.clear()
        try:
            self.filepath.write_text("", encoding="utf-8")
        except OSError as e:
            print(f"{Colors.RED}[!] Write error: {e}{Colors.RESET}")

    def add(self, domain: str):
        with self._lock:
            if domain in self._domains:
                return
            self._domains.add(domain)
            try:
                with open(self.filepath, "a", encoding="utf-8") as f:
                    f.write(domain + "\n")
            except OSError as e:
                print(f"{Colors.RED}[!] Write error: {e}{Colors.RESET}")

    def count(self) -> int:
        return len(self._domains)


# ============================================================================
# PROGRESS TRACKER
# ============================================================================

class ProgressTracker:
    def __init__(self):
        self.total = 0
        self.processed = 0
        self.found = 0
        self.current = ""
        self._timer: Optional[threading.Timer] = None
        self._running = False
        self._print_lock = threading.Lock()

    def start(self):
        self._running = True
        self._schedule_update()

    def stop(self):
        self._running = False
        if self._timer:
            self._timer.cancel()

    def _schedule_update(self):
        if not self._running:
            return
        self._update_title()
        self._timer = threading.Timer(0.5, self._schedule_update)
        self._timer.daemon = True
        self._timer.start()

    def set_total(self, total: int):
        self.total = total

    def increment_processed(self):
        with self._print_lock:
            self.processed += 1

    def increment_found(self, n: int = 1):
        with self._print_lock:
            self.found += n

    def set_current(self, item: str):
        self.current = item

    def set_completed(self):
        self.processed = self.total

    def _update_title(self):
        title = (f"Item: {self.processed}/{self.total} | "
                 f"Domains: {self.found} | Current: {self.current}")
        try:
            ctypes.windll.kernel32.SetConsoleTitleW(title)
        except Exception:
            pass


# ============================================================================
# WORKER — one unit per input line (dork or IP)
# ============================================================================

class Harvester:
    def __init__(self, search_engine: BingSearchEngine,
                 repository: DomainRepository, progress: ProgressTracker,
                 mode: str):
        self.search_engine = search_engine
        self.repository = repository
        self.progress = progress
        self.mode = mode  # 'dork' or 'ip'

    def process(self, item: str):
        self.progress.set_current(item)
        if self.mode == 'ip':
            domains = self.search_engine.search_ip(item)
        else:
            domains = self.search_engine.search_dork(item)
        for domain in domains:
            self.repository.add(domain)
        self.progress.increment_found(len(domains))
        self.progress.increment_processed()


# ============================================================================
# APPLICATION
# ============================================================================

class Application:
    def __init__(self):
        self.settings = Settings().load()
        self.proxy_manager = ProxyManager()
        self.exclusion_filter = ExclusionFilter()
        self.repository = DomainRepository()
        self.progress = ProgressTracker()
        self.search_engine: Optional[BingSearchEngine] = None

    def _clear_screen(self):
        import os
        os.system("cls" if platform.system() == "Windows" else "clear")

    def setup(self):
        print(f"{Colors.CYAN}[*] Settings: proxy="
              f"{'yes' if self.settings.use_proxy else 'no'}"
              f" | workers={self.settings.max_workers}"
              f" | timeout={self.settings.request_timeout}s{Colors.RESET}")
        if self.settings.use_proxy:
            self.proxy_manager.load()
            if not self.proxy_manager.enabled:
                print(f"{Colors.YELLOW}[!] Proxy wanted but none available "
                      f"— searching direct{Colors.RESET}")
        else:
            print(f"{Colors.CYAN}[*] Searching direct from your IP{Colors.RESET}")
        self.exclusion_filter.load()
        self.search_engine = BingSearchEngine(
            self.proxy_manager, self.exclusion_filter, self.settings)
        self.repository.reset()

    def _read_list(self, prompt: str, validator) -> Optional[List[str]]:
        """Read a list file, validate each line, return clean items."""
        list_path = input(f"{Colors.CYAN}{prompt}{Colors.RESET}").strip()
        path = Path(list_path)
        if not path.exists():
            print(f"{Colors.RED}[!] File not found: {list_path}"
                  f"{Colors.RESET}")
            return None
        raw = [
            line.strip()
            for line in path.read_text(encoding="utf-8", errors="ignore").splitlines()
            if line.strip()
        ]
        items = []
        skipped = 0
        for line in raw:
            if validator(line):
                items.append(line)
            else:
                skipped += 1
        if skipped:
            print(f"{Colors.YELLOW}[!] Skipped {skipped} invalid lines"
                  f"{Colors.RESET}")
        if not items:
            print(f"{Colors.RED}[!] No valid items found{Colors.RESET}")
            return None
        return items

    @staticmethod
    def _valid_ip(line: str) -> bool:
        try:
            ipaddress.IPv4Address(line)
            return True
        except ValueError:
            return False

    @staticmethod
    def _valid_any(line: str) -> bool:
        return len(line) > 2

    def run(self):
        # --- mode selection ---
        print(f"{Colors.CYAN}\n  MODE SELECTION")
        print(f"  1) DORK — search queries in, result domains out")
        print(f"  2) IP   — IP list in, hosted sites out (Bing ip: search)"
              f"{Colors.RESET}")
        mode_input = input(f"{Colors.CYAN}  Choose [1/2]: {Colors.RESET}").strip()
        if mode_input == '2':
            mode = 'ip'
            items = self._read_list("[+] Enter IP List: ", self._valid_ip)
        else:
            mode = 'dork'
            items = self._read_list("[+] Enter Dork List: ", self._valid_any)
        if items is None:
            return

        self.progress.set_total(len(items))
        label = 'IPs' if mode == 'ip' else 'dorks'
        print(f"{Colors.CYAN}[#] Processing {len(items)} {label} with "
              f"{self.settings.max_workers} workers{Colors.RESET}")

        harvester = Harvester(
            self.search_engine, self.repository, self.progress, mode)

        start_time = time.time()
        self.progress.start()
        with ThreadPoolExecutor(max_workers=self.settings.max_workers) as executor:
            futures = [executor.submit(harvester.process, item)
                       for item in items]
            for future in as_completed(futures):
                try:
                    future.result()
                except Exception as e:
                    print(f"{Colors.RED}[!] Worker error: {e}{Colors.RESET}")
        self.progress.set_completed()
        self.progress.stop()

        elapsed = time.time() - start_time
        print(f"{Colors.GREEN}[+] Completed in {elapsed:.2f}s{Colors.RESET}")
        print(f"{Colors.GREEN}[+] Unique domains: "
              f"{self.repository.count()}{Colors.RESET}")
        print(f"{Colors.GREEN}[+] Output: {Config.OUTPUT_FILE}{Colors.RESET}")

    def main(self):
        self._clear_screen()
        print(Config.BANNER)
        self.setup()
        self.run()


def main():
    app = Application()
    try:
        app.main()
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}[-] Interrupted by user{Colors.RESET}")
    except Exception as e:
        print(f"{Colors.RED}[-] Fatal error: {e}{Colors.RESET}")


if __name__ == "__main__":
    main()
